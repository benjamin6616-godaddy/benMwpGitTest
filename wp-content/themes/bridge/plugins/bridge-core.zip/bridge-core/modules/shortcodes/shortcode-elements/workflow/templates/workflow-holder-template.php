<div class="qode-workflow <?php echo esc_attr($el_class) ?>">
    <span class="main-line" style="<?php echo esc_attr($main_line_style); ?>"></span>
    <?php echo bridge_core_remove_auto_ptag($content) ?>
</div>